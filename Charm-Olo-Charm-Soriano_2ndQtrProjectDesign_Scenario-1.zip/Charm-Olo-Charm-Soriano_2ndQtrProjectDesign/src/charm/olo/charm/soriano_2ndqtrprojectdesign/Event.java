/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package charm.olo.charm.soriano_2ndqtrprojectdesign;

import java.util.Random;

/**
 *
 * @author timrs
 */
public class Event implements Action{
    private boolean boolDunkContest = false;
    private boolean boolPlayGame = false;
    private boolean boolSignDeal = false;
    private boolean boolPersonalTrainer = false;
    private boolean boolShootShot = false;
    
    public void chooseEvent(Player p) {
        System.out.println("Which event would you like to do?");
    }
    public void dunkContest(Player p) {
    try {
        if (!p.isIsInjured()) {
            if (!boolDunkContest) {
                boolDunkContest = true;
                System.out.println("Which dunk would you like to do?");
            } else {
                throw new AlreadyExecutedException("Dunk contest already completed!");
            }
        } else {
            throw new InjuredException("You are injured and cannot participate in the dunk contest!");
        }
    } catch (AlreadyExecutedException e) {
        System.out.println(e.getMessage());
    } catch (InjuredException e) {
        System.out.println(e.getMessage());
    }
}
    
    public void reverseDunk(Player p) {
    try {
        if (p.getOvr() > 65) {
            System.out.println("Dunk successful! Popularity increased by 1000!");
            p.setPopularity(p.getPopularity() + 1000);
        } else {
            System.out.println("Dunk unsuccessful! You are now injured!");
            p.setIsInjured(true);
        }
    } catch (Exception e) {
        System.out.println(e.getMessage());
    }
}

public void jumpOverDunk(Player p) {
    try {
        if (p.getOvr() > 75) {
            System.out.println("Dunk successful! Popularity increased by 5000!");
            p.setPopularity(p.getPopularity() + 5000);
        } else {
            System.out.println("Dunk unsuccessful! You are now injured!");
            p.setIsInjured(true);
        }
    } catch (Exception e) {
        System.out.println(e.getMessage());
    }
}

public void spinDunk(Player p) {
    try {
        if (p.getOvr() > 90) {
            System.out.println("Dunk successful! Popularity increased by 20000!");
            p.setPopularity(p.getPopularity() + 20000);
        } else {
            System.out.println("Dunk unsuccessful! You are now injured!");
            p.setIsInjured(true);
        }
    } catch (Exception e) {
        System.out.println(e.getMessage());
    }
}

public void playGame(Player p) {
    try {
        if (!p.isIsInjured()) {
            if (!boolPlayGame) {
                boolPlayGame = true;
                Random random = new Random();
                Random ovr = new Random();
                int overall = ovr.nextInt(2) + 1;
                double chance = random.nextDouble();
                if (chance < 0.5) {
                    System.out.println("Game won! Overall increased by " + overall + "!");
                    p.setOvr(p.getOvr() + overall);
                } else {
                    System.out.println("Game lost! Overall decreased by " + overall + "!");
                    p.setOvr(p.getOvr() - overall);
                }
            } else {
                throw new AlreadyExecutedException("Game already played this year!");
            }
        } else {
            throw new InjuredException("You are injured and cannot play a game!");
        }
    } catch (Exception e) {
        System.out.println(e.getMessage());
    }
}

public void signDeal(Player p) {
    try {
        if (!boolSignDeal) {
            boolSignDeal = true;
            Random pop = new Random();
            int popularity = pop.nextInt(10000) + 10000;
            if (p.getPopularity() > 100000) {
                System.out.println("Secured a sponsorship!");
                p.setPopularity(p.getPopularity() + popularity);
            } else {
                System.out.println("Not popular enough!");
            }
        } else {
            throw new AlreadyExecutedException("Sponsorship already signed this year!");
        }
    } catch (Exception e) {
        System.out.println(e.getMessage());
    }
}

public void personalTrainer(Player p) {
    try {
        if (!p.isIsInjured()) {
            if (!boolPersonalTrainer) {
                boolPersonalTrainer = true;
                Random random = new Random();
                Random ovr = new Random();
                int overall = ovr.nextInt(2) + 1;
                double chance = random.nextDouble();
                if (chance < 0.8) {
                    System.out.println("Training session successful! Overall increased by " + overall + "!");
                    p.setOvr(p.getOvr() + overall);
                } else {
                    System.out.println("Training session failed! Overall decreased by " + overall + "! You are now also injured!");
                    p.setOvr(p.getOvr() - overall);
                    p.setIsInjured(true);
                }
            } else {
                throw new AlreadyExecutedException("Already trained this year!");
            }
        } else {
            throw new AlreadyExecutedException("You are injured and cannot train!");
        }
    } catch (Exception e) {
        System.out.println(e.getMessage());
    }
}

public void shootShot(Player p) {
    try {
        if (!boolShootShot) {
            boolShootShot = true;
            Random random = new Random();
            Random pop = new Random();
            int popularity = pop.nextInt(10000) + 1000000;
            double chance = random.nextDouble();
            if (chance < 0.01 || popularity > 10000000) {
                System.out.println("Nice One! Popularity increased by " + popularity + "!");
                p.setPopularity(p.getPopularity() + popularity);
            } else {
                System.out.println("Heartbroken! Popularity decreased by " + popularity + "! You are now also injured!");
                p.setPopularity(p.getPopularity() - popularity);
                p.setIsInjured(true);
            }
        } else {
            throw new AlreadyExecutedException("You have already shot your shot!");
        }
    } catch (Exception e) {
        System.out.println(e.getMessage());
    }
}

    
    @Override
    public void newYear(Player p) {
        boolDunkContest = false;
        boolPlayGame = false;
        boolSignDeal = false;
        boolPersonalTrainer = false;
        boolShootShot = false;
        p.setIsInjured(false);
        p.setYear(p.getYear() + 1);
    }
}
