/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package charm.olo.charm.soriano_2ndqtrprojectdesign;

/**
 *
 * @author timrs
 */
public class Player {
    private String name;
    private int ovr;
    private int height;
    private int weight;
    private int popularity;
    private String position;
    private boolean isInjured = false;
    private int year = 0;
    
    public Player(String n, String pos, int h, int w){
        name = n;
        position = pos;
        height = h;
        weight = w;
        ovr = 60;
        popularity = 100000;
        isInjured = false;
    }
    public Player(String n, String pos, int h, int w, int p){
        name = n;
        position = pos;
        height = h;
        weight = w;
        ovr = 60;
        popularity = p;
    }
    
    public void Retire() {
        System.out.println("Congratulations! You've retired with an overall of" + ovr + ". After a career of " + year + " years, filled with epic plays and wild adventures, you're ready for a new chapter! Plan to spend retirement perfecting your golf swing and dominating the world of esports. Best of luck in this exciting new phase of life!");
        System.exit(0);
    }
    
     public void outputPlayerStats() {
        System.out.println("Player: " + name + ", Position: " + position + ", Overall: " + getOvr() + ", Height: " + height + " cm, Weight: " + weight + " kg, Popularity: " + getPopularity() );
    }

    /**
     * @return the ovr
     */
    public int getOvr() {
        return ovr;
    }

    /**
     * @param ovr the ovr to set
     */
    public void setOvr(int ovr) {
        this.ovr = ovr;
    }

    /**
     * @return the popularity
     */
    public int getPopularity() {
        return popularity;
    }

    /**
     * @param popularity the popularity to set
     */
    public void setPopularity(int popularity) {
        this.popularity = popularity;
    }

    /**
     * @return the isInjured
     */
    public boolean isIsInjured() {
        return isInjured;
    }

    /**
     * @param isInjured the isInjured to set
     */
    public void setIsInjured(boolean isInjured) {
        this.isInjured = isInjured;
    }

    /**
     * @return the year
     */
    public int getYear() {
        return year;
    }

    /**
     * @param year the year to set
     */
    public void setYear(int year) {
        this.year = year;
    }
}
