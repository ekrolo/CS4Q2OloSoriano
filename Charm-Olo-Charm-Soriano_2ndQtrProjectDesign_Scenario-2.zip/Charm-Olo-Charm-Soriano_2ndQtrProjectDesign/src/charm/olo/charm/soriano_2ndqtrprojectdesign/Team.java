/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package charm.olo.charm.soriano_2ndqtrprojectdesign;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author timrs
 */
public class Team {
    private String name;
    ArrayList<Player> playerList = new ArrayList<>();
    private Random random = new Random();
    private int maxPlayers = 13;

    public Team(String n) {
        name = n;
    }
    
    public void chooseTeam(Player p) {
        playerList.clear();
        playerList.add(p);
        assignPlayersToTeam();
    }
    
    private String generateRandomPlayerName() {
        String[] first = {"LeBron", "Kevin", "Stephen", "Giannis", "James", "Anthony", "Kawhi", "Luka", "Damian", "Joel", "Devin", "Ben", "Jayson", "Zion", "Trae", "Jaylen", "Jimmy", "Chris", "Xiu", "Russell", "Donovan", "Kyrie", "Karl-Anthony", "Bradley", "D'Angelo", "DeAndre", "Gordon", "Andre", "DeMarcus", "Jamal", "Victor", "Kemba", "Myles", "Jerami", "Rudy", "Hakeem", "Leviticus", "Derrick", "Ronaldo", "Montrezl", "Martynas", "Kentavious", "Nickeil", "Cornelius", "Rondae", "Timothe", "Shai", "Thanasis", "Micheal Ray", "Aleksandar", "Crisostomo"};
        
        String[] last = {"James", "Antetokounmpo", "Curry", "Davis", "Harden", "Towns", "Leonard", "Doncic", "Lillard", "Embiid", "Booker", "Simmons", "Tatum", "Williamson", "Young", "Brown", "Butler", "Zhang", "George", "Westbrook", "Mitchell", "Irving", "Towns", "Epstein", "Tatum", "Olajuwon", "McCollum", "Middleton", "Oghenetega Tamaraebi Bakumo-Abraham", "DeRozan", "Ibrahimovic", "Abdul-Jabaar", "Ingram", "Morant", "Mcdonaldo", "Adebayo", "Porzingis", "Ball", "LaVine", "Jokic", "Russell", "Oatmeal", "Oladipo", "Drummond", "Hayward", "Iguodala", "Murray", "Walker", "Turner", "Grant", "Gobert", "Bledsoe", "Curry", "Ibarra", "Williams", "Wembanyama", "Andriuskevicius", "Caldwell-Pope", "Alexander-Walker", "Carter-Williams", "Hollis-Jefferson-Smith", "Luwawu-Cabarrot", "Gilgeous-Alexander", "Antetokounmpo", "Richardson", "Djordjevic", "Weatherspoon"};
        
        String firstName = first[random.nextInt(first.length)];
        String lastName = last[random.nextInt(last.length)];
        return firstName + " " + lastName;
    }
    
    private String getRandomPosition() {
        String[] positions = {"PG", "SG", "SF", "PF", "C"};
        return positions[random.nextInt(positions.length)];
    }
    
    private int getRandomHeight() {
        Random random = new Random();
        int height = random.nextInt(50) + 170;
        return height;
    }
    
    private int getRandomWeight() {
        Random random = new Random();
        int weight = random.nextInt(150) + 110;
        return weight;
    }
    
    private int getRandomPopularity() {
        Random random = new Random();
        int popularity = random.nextInt(200000000) + 100000;
        return popularity;
    }
    
    public void assignPlayersToTeam() {
    int max = maxPlayers - playerList.size();

        for (int i = 0; i < max; i++) {
            Player p = new Player(generateRandomPlayerName(), getRandomPosition(), getRandomHeight(), getRandomWeight(), getRandomPopularity());
            playerList.add(p);
        }
    }

    public void outputTeamStats() {
        System.out.println("Team: " + name);
        for (Player player : playerList) {
            player.outputPlayerStats();
        }
        System.out.println("--------------\n");
    }
}