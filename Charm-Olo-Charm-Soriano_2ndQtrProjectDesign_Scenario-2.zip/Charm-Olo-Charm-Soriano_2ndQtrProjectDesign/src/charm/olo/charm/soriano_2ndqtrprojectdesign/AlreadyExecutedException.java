/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Exception.java to edit this template
 */
package charm.olo.charm.soriano_2ndqtrprojectdesign;

/**
 *
 * @author timrs
 */
public class AlreadyExecutedException extends RuntimeException {

    /**
     * Creates a new instance of <code>AlreadyExecutedException</code> without
     * detail message.
     */
    public AlreadyExecutedException() {
    }

    /**
     * Constructs an instance of <code>AlreadyExecutedException</code> with the
     * specified detail message.
     *
     * @param msg the detail message.
     */
    public AlreadyExecutedException(String msg) {
        super(msg);
    }
}
