/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package charm.olo.charm.soriano_2ndqtrprojectdesign;

import java.util.Random;

/**
 *
 * @author timrs
 */
public class Train implements Action{
    int totalTrained = 0;
    public void chooseTrain(Player p) {
        System.out.println("How intense would you like to train?");
    }
    
    public void lightTrain(Player p) {
    try {
        if (!p.isIsInjured()) {
            if (totalTrained < 2) {
                totalTrained++;
                Random random = new Random();
                double chance = random.nextDouble();
                if (chance < 0.9) {
                    System.out.println("Training session successful! Overall increased by 1!");
                    p.setOvr(p.getOvr() + 1);
                } else {
                    System.out.println("Training session failed! Overall decreased by 1! You are now also injured!");
                    p.setOvr(p.getOvr() - 1);
                    p.setIsInjured(true);
                }
            } else {
                throw new AlreadyExecutedException("You have already trained twice this year!");
            }
        } else {
            throw new InjuredException("You are injured and cannot train!");
        }
    } catch (AlreadyExecutedException e) {
        System.out.println(e.getMessage());
    } catch (InjuredException e) {
        System.out.println(e.getMessage());
    }
}

public void mediumTrain(Player p) {
    try {
        if (!p.isIsInjured()) {
            if (totalTrained < 2) {
                totalTrained++;
                Random random = new Random();
                double chance = random.nextDouble();
                if (chance < 0.7) {
                    System.out.println("Training session successful! Overall increased by 2!");
                    p.setOvr(p.getOvr() + 2);
                } else {
                    System.out.println("Training session failed! Overall decreased by 2! You are now also injured!");
                    p.setOvr(p.getOvr() - 2);
                    p.setIsInjured(true);
                }
            } else {
                throw new AlreadyExecutedException("You have already trained twice this year!");
            }
        } else {
            throw new InjuredException("You are injured and cannot train!");
        }
    } catch (AlreadyExecutedException e) {
        System.out.println(e.getMessage());
    } catch (InjuredException e) {
        System.out.println(e.getMessage());
    }
}

public void intenseTrain(Player p) {
    try {
        if (!p.isIsInjured()) {
            if (totalTrained < 2) {
                totalTrained++;
                Random random = new Random();
                double chance = random.nextDouble();
                if (chance < 0.5) {
                    System.out.println("Training session successful! Overall increased by 3!");
                    p.setOvr(p.getOvr() + 3);
                } else {
                    System.out.println("Training session failed! Overall decreased by 3! You are now also injured!");
                    p.setOvr(p.getOvr() - 3);
                    p.setIsInjured(true);
                }
            } else {
                throw new AlreadyExecutedException("You have already trained twice this year!");
            }
        } else {
            throw new InjuredException("You are injured and cannot train!");
        }
    } catch (AlreadyExecutedException e) {
        System.out.println(e.getMessage());
    } catch (InjuredException e) {
        System.out.println(e.getMessage());
    }
}
    
    @Override
    public void newYear(Player p) {
        totalTrained=0;
        p.setIsInjured(false);
        p.setYear(p.getYear() + 1);
    }
}
