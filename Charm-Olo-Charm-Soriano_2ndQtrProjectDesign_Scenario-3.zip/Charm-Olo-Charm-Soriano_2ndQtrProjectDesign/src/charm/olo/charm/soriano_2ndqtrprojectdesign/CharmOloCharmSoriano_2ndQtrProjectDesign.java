/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package charm.olo.charm.soriano_2ndqtrprojectdesign;

/**
 *
 * @author timrs
 */
public class CharmOloCharmSoriano_2ndQtrProjectDesign {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Event e = new Event();
        Train t = new Train();
        Team t1 = new Team("Rain or Shine");
        Team t2 = new Team("La Salle");
        
        t1.assignPlayersToTeam();
        t2.assignPlayersToTeam();
        
        System.out.println("Create your Player!");
        Player p1 = new Player("Mr. Quantavious Dingleberry IV Jr., PhD", "SG", 100, 1520);
        System.out.println("Choose your Team!");
        t1.chooseTeam(p1);
        e.chooseEvent(p1);
        e.playGame(p1);
        e.newYear(p1);
        p1.Retire();
        
        
    }
    
}
