/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Exception.java to edit this template
 */
package charm.olo.charm.soriano_2ndqtrprojectdesign;

/**
 *
 * @author timrs
 */
public class InjuredException extends RuntimeException{

    /**
     * Creates a new instance of <code>InjuredException</code> without detail
     * message.
     */
    public InjuredException() {
    }

    /**
     * Constructs an instance of <code>InjuredException</code> with the
     * specified detail message.
     *
     * @param msg the detail message.
     */
    public InjuredException(String msg) {
        super(msg);
    }
}
